// content.js
console.log('Content script injected and running');


(async function() {

    
  if (window.downloadInitiated) {
    console.log('Script already initialized. Exiting to avoid redeclaration errors.');
    return;
  }
  window.downloadInitiated = false;
  // Function to fetch blob from a given URL
  const fetchBlob = async url => {
    console.log(`Starting to fetch blob from URL: ${url}`);
    // Fetching the response from the URL
    const response = await fetch(url);
    console.log(`Received response from URL: ${url}`);
    // Converting the response to a blob
    const blob = await response.blob();
    console.log(`Converted response to blob from URL: ${url}`);
    // Converting the blob to base64
    const base64 = await convertBlobToBase64(blob);
    console.log(`Converted blob to base64 from URL: ${url}`);
    return base64;
  };

  // Function to convert a blob to base64
  const convertBlobToBase64 = blob => new Promise(resolve => {
    console.log('Starting to convert blob to base64');
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onloadend = () => {
      const base64data = reader.result;
      console.log('Finished converting blob to base64');
      resolve(base64data);
    };
  });

  // Function to download PDFs from given links
  async function downloadPDFs(links) {
    console.log('Starting to download PDFs');
    const pdfs = [];
    for (let i = 0; i < links.length; i++) {
      const link = links[i];
      console.log(`Attempting to download PDF from link: ${link}`);
      try {
        console.log(`Fetching from link: ${link}`);
        // Fetching the blob and converting it to base64
        const base64 = await fetchBlob(link);
        console.log(`Fetched and converted to base64 from link: ${link}`, base64);

        // Adding the base64 data to the PDFs array
        pdfs.push(base64);
        console.log(`Successfully downloaded PDF from link: ${link}`);

        // Send progress update to the popup script
        chrome.runtime.sendMessage({
          action: 'pdfDownloadProgress',
          downloaded: i + 1,
          total: links.length
        });
      } catch (error) {
        console.error(`Failed to download PDF from link: ${link}`, error);
      }
    }
    console.log('Finished downloading PDFs');
    return pdfs;
  }

  // Function to extract PDF links from the page based on the provided table structure
  function extractPDFLinks() {
    console.log('Extracting PDF links from the page');
    const url = window.location.href;
    let pdfLinks = [];

    // Check if the current page is the specific PennDOT ECMS document list page
    if (url === 'https://www.ecms.penndot.pa.gov/ECMS/SVCOMDownloadDocument?action=showList') {
      // Specific logic for extracting PDF links from the PennDOT ECMS page
      const tableRows = document.querySelectorAll('table.results tr');
      tableRows.forEach(row => {
        const linkElement = row.querySelector('a.results');
        if (linkElement && linkElement.href.includes('SVCOMDownloadDocument')) {
          pdfLinks.push(linkElement.href);
          console.log(`Extracted specific PDF link: ${linkElement.href}`);
        }
      });
    } else {
      // General extraction logic for other pages
      const anchorTags = document.querySelectorAll('a.document');
      anchorTags.forEach(tag => {
        if (tag.href.includes('DownloadDocument') && tag.innerText.trim().toUpperCase().endsWith('.PDF')) {
          pdfLinks.push(tag.href);
          console.log(`Extracted PDF link: ${tag.href}`);
        }
      });
    }

    const pdfLinksCount = pdfLinks.length;
    console.log(`Extracted ${pdfLinksCount} PDF links from the page`);

    // Optionally, send message to popup with the count of PDFs
    // chrome.runtime.sendMessage({ action: 'pdfCount', count: pdfLinksCount });

    return pdfLinks;
  }

  // Listen for messages from the popup script
  chrome.runtime.onMessage.addListener(async function(request, sender, sendResponse) {
    if (request.action === "mergePdfs") {
      console.log('Received a request to merge PDFs');
      // Extracting PDF links for merging
      const pdfLinks = extractPDFLinks();
      console.log('Extracted PDF links for merging');
      // Downloading PDFs for merging
      const pdfData = await downloadPDFs(pdfLinks);
      console.log('Downloaded PDFs for merging');
      console.log('Sending PDF data to background script for merging');
      // Sending the PDF data to the background script for merging
      chrome.runtime.sendMessage({ action: 'mergePdfs', pdfData: pdfData });
      console.log('Sent PDF data to background script for merging');
    }
  });

  // Listen for messages from the background script
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "mergedPdfData") {
      console.log('Received merged PDF data');
      // Getting the merged PDF data
      const mergedPdfData = request.pdfData;
      // Downloading the merged PDF
      downloadMergedPdf(mergedPdfData);
    }
  });

  // Function to download the merged PDF
  function downloadMergedPdf(base64Data) {
    if (window.downloadInitiated) {
      console.log('Download already initiated. Ignoring subsequent calls.');
      return;
    }
    window.downloadInitiated = true;

    // Safe getter for text content with default value
    const getTextContent = (selector, defaultValue = '') => {
      const element = document.querySelector(selector);
      return element ? element.textContent.trim() : defaultValue;
    };

    // Safe getter for XPath with default value
    const getXPathTextContent = (xpath, defaultValue = '') => {
      const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
      return result.singleNodeValue ? result.singleNodeValue.textContent.trim() : defaultValue;
    };

    // Extracting the project number from the element with class 'header1title'
    const projectNumberElement = getTextContent('td.header1title', '0000');
    const projectNumber = projectNumberElement.replace(/[^0-9]/g, ''); // Remove all non-numeric characters
    // Extracting the plan name using the full xpath
    const planName = getXPathTextContent('/html/body/div[33]/table/tbody/tr/td/form/table[2]/tbody/tr/td/table[1]/tbody/tr/td', 'Plan');
    const formattedPlanName = planName.toLowerCase().includes('plan') ? planName : `${planName}_plan`;
    const fileName = `ECMS_${projectNumber}_${formattedPlanName}`.replace(/\s+/g, '_');
    chrome.runtime.sendMessage({
      action: 'mergedPdfAvailable',
      pdfData: base64Data,
      namingData: fileName
    });
    console.log('downloadrdy msg sent')

    // // Creating a download link for the merged PDF
    // const link = document.createElement('a');
    // link.href = base64Data;
    // link.download = fileName || 'download_merged.pdf'; // Fallback file name
    // document.body.appendChild(link);
    // link.click();
    // document.body.removeChild(link);
    // console.log('Merged PDF has been downloaded with the name: ' + fileName);
  }

})(); 
console.log("Popup script loaded");

let licenseInput, verifyButton, otherButtonsContainer, licenseVerified = false;



function showProgressBarAndHideOthers() {
  // Check if elements exist before trying to modify them
  if (licenseInput) licenseInput.style.display = 'none';
  if (verifyButton) verifyButton.style.display = 'none';
  if (otherButtonsContainer) otherButtonsContainer.style.display = 'none';

  const progressContainer = document.getElementById('progress-container');
  if (progressContainer) {
    progressContainer.style.display = 'block';

    const progressBar = document.getElementById('progress-bar');
    if (progressBar) {
      progressBar.style.width = '0%'; // Reset progress or set to current progress if known
      progressBar.style.display = 'block'; // Make sure it's visible
    }
  }

  const mergeButton = document.getElementById('merge');
  mergeButton.style.display = 'block'; // Ensure it's visible
  mergeButton.disabled = true; // Keep it disabled
  mergeButton.textContent = 'Creating...'; // Indicate an ongoing operation
  // Example: Adjust the overall layout container if necessary
  const layoutContainer = document.getElementById('layout-container'); // Assuming you have this
  layoutContainer.style.display = 'flex'; // Or 'block', depending on your layout
  layoutContainer.style.flexDirection = 'column'; // Example for a flex layout
}

function updateUIBasedOnLicense(isValid) {
  // Check if isValid is explicitly false to avoid alerting on undefined
  if (isValid === false) {
    alert('Invalid license key. Please try again.');
  } else if (isValid && !licenseVerified) {
    licenseVerified = true;
    licenseInput.style.display = 'none';
    verifyButton.style.display = 'none';
    otherButtonsContainer.style.display = 'block';
    console.log("License input and verify button are now hidden. Other buttons container is now visible");
  }
}

function getLicenseStatus(callback) {
  chrome.storage.local.get(['licenseValid'], function(result) {
    // Only call the callback if licenseValid exists in the result
    if (result.hasOwnProperty('licenseValid')) {
      callback(result.licenseValid);
    } else {
      console.log('License status is not set yet.');
    }
  });
}

function verifyLicense(licenseKey) {
  chrome.runtime.sendMessage({action: "verifyLicense", licenseKey: licenseKey});
}

document.addEventListener('DOMContentLoaded', function() {
  
  licenseInput = document.getElementById('license-key');
  verifyButton = document.getElementById('verify-button');
  otherButtonsContainer = document.getElementById('merge-container');
  const mergeButton = document.getElementById('merge');

  // Initially hide other buttons and disable merge button
  otherButtonsContainer.style.display = 'none';
  mergeButton.disabled = true;

  // Check if a download is in progress and update UI accordingly
  chrome.storage.local.get(['downloading'], function(result) {
    if (result.downloading) {
      // Assuming you have a function to show the progress bar and hide other elements
      showProgressBarAndHideOthers();
    } else {
      // Existing code to set up UI based on license status
      getLicenseStatus(updateUIBasedOnLicense);
    }
  });

  verifyButton.addEventListener('click', () => {
    verifyLicense(licenseInput.value);
  });

  // Check the current tab's URL before enabling the merge button
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const url = tabs[0].url;
    // Check if the current URL starts with the base URL
    if (url.startsWith('https://www.ecms.penndot.pa.gov/')) {
      // Enable the merge button if the URL is correct
      mergeButton.disabled = false;
    } else {
      // Inform the user that the button is disabled due to incorrect URL
      mergeButton.textContent = 'Unavailable for this URL';
    }
  });

  mergeButton.addEventListener('click', function() {
    if (this.disabled) {
      alert('This function is not available for the current URL.');
      return;
    }
    chrome.storage.local.set({downloading: true});
    this.textContent = 'Creating...';
    this.disabled = true;

    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const url = tabs[0].url;
      if (url.startsWith('http://') || url.startsWith('https://')) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          files: ["content.js"]
        }).then(() => {
          chrome.tabs.sendMessage(tabs[0].id, {action: "mergePdfs"});
        }).catch(err => {
          console.error(err);
          // Optionally, handle the error for the user here
        });
      } else {
        console.log('Cannot inject content script into this URL:', url);
      }
    });
  });
});

let lastKnownProgress = 0;

chrome.runtime.onMessage.addListener(function(message, sender) {
  if (message.action === 'mergedPdfAvailable') {
    // Extract the naming data
    
    document.getElementById('progress-container').style.display = 'none';
    lastKnownProgress = 0;
    const fileName = message.namingData;

    // Hide other UI elements
    licenseInput.style.display = 'none';
    verifyButton.style.display = 'none';
    otherButtonsContainer.style.display = 'none';

    // Set up the download link
    const downloadLinkContainer = document.getElementById('download-link-container');
    const downloadLink = document.getElementById('download-link');
    downloadLink.href = message.pdfData; // The base64 PDF data
    downloadLink.download = fileName; // Use the naming data for the file name
    downloadLinkContainer.style.display = 'block'; // Show the download link container only when the merged PDF is available
    chrome.storage.local.set({downloading: false});
  }
  if (message.action === 'pdfCount') {
    const mergeButton = document.getElementById('merge');
    mergeButton.textContent = `Creating ${message.count} PDFs...`;
  } else if (message.action === 'pdfDownloadProgress') {
    const progressBar = document.getElementById('progress-bar');
    const progressContainer = document.getElementById('progress-container');
    progressContainer.style.display = 'block'; // Show the progress bar container

    // Calculate the percentage of completion
    const percentage = (message.downloaded / message.total) * 100;

    // Update the progress bar only if the new percentage is greater than or equal to the last known progress
    if (percentage >= lastKnownProgress) {
      progressBar.value = percentage; // Update the progress bar
      lastKnownProgress = percentage; // Update the last known progress
    }

    // Optionally, hide the progress bar when download is complete
    if (message.downloaded === message.total) {
      progressContainer.style.display = 'none';
      lastKnownProgress = 0;
      chrome.storage.local.set({downloading: false});
    }

  } else if (message.action === 'licenseStatusUpdated') {
    getLicenseStatus(updateUIBasedOnLicense);
  }
});
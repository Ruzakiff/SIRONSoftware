// background.js

// Importing the PDF library to use for merging PDFs
importScripts('pdf-lib.min.js');

console.log("Background script loaded");

let mergeInProgress = false;

// Function to import the public key from PEM format
async function importPublicKey(pem) {
  // Fetch the part of the PEM string between header and footer
  const pemHeader = "-----BEGIN PUBLIC KEY-----";
  const pemFooter = "-----END PUBLIC KEY-----";
  const pemContents = pem.substring(pemHeader.length, pem.length - pemFooter.length).trim();
  // Base64 decode the string to get the binary data
  const binaryDerString = atob(pemContents);
  // Convert from a binary string to an ArrayBuffer
  const binaryDer = str2ab(binaryDerString);

  return self.crypto.subtle.importKey(
    "spki",
    binaryDer,
    {
      name: "RSA-OAEP",
      hash: "SHA-256",
    },
    true,
    ["encrypt"]
  );
}

// Utility function to convert a binary string to an ArrayBuffer
function str2ab(str) {
  const buf = new ArrayBuffer(str.length);
  const bufView = new Uint8Array(buf);
  for (let i = 0, strLen = str.length; i < strLen; i++) {
    bufView[i] = str.charCodeAt(i);
  }
  return buf;
}

// Function to encrypt data with the public key using SubtleCrypto
async function encryptWithPublicKey(data, cryptoKey) {
  const encoder = new TextEncoder();
  const dataBytes = encoder.encode(data);

  try {
    const encryptedData = await self.crypto.subtle.encrypt(
      {
        name: "RSA-OAEP",
        hash: { name: "SHA-256" },
      },
      cryptoKey,
      dataBytes
    );
    return btoa(String.fromCharCode(...new Uint8Array(encryptedData)));
  } catch (error) {
    console.error('Error encrypting data:', error);
    throw error;
  }
}

// Function to check the license and store the result in Chrome storage
async function checkLicense(licenseKey, uuid) {
  const licenseServerUrl = 'https://ecms-server-ca35422abdfd.herokuapp.com/validate-license';

  try {
    // Import the public key (replace with your actual public key)
    const publicKeyPem = `-----BEGIN PUBLIC KEY-----
    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAws31srvea1Yz66oj/dLP
    Zn5FtDP6dnJTWLMADg8Jz08ofeJ7Egfgtk+FQUXiOWn13J5cKHd3JHzFap2bE+y3
    VfYLWoRoOfoO/1GqVYJj5tWSyYsPZeMlVjrJdsSoAMm1nG1BCd/n8I/tQ/+xk3tp
    808h6g92/w7MF50Xg2RDyhAZfc2+o/Y2rGha+cVfh5PE67Vqvy094UhASTXrUcto
    VIkfmNwQZcKjtI5hi9nHOFbMW3GALJu6sLLNGTd+QGquaiQN97Q4/s9QbM3CjUlc
    lRzufCqk8v97Wa3CZYqqq2LX3tkop3IU9rtJ2QbAwuVkkQF/sa3IUwbyqSXe8Kh/
    OwIDAQAB
    -----END PUBLIC KEY-----`;
    const cryptoKey = await importPublicKey(publicKeyPem);

    // Encrypt the license key
    const encryptedLicenseKey = await encryptWithPublicKey(licenseKey, cryptoKey);

    // Continue with the fetch request using the encrypted license key
    const response = await fetch(licenseServerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ encrypted_license_key: encryptedLicenseKey, uuid: uuid }),
    });

    if (!response.ok) {
      console.error('License verification failed with status:', response.status);
      chrome.runtime.sendMessage({ action: "licenseStatusUpdated" });
      return false;
    }

    const data = await response.json();
    console.log('Server response data:', JSON.stringify(data, null, 2));

    if (typeof data.valid !== 'boolean') {
      console.error('Unexpected structure for "valid":', data);
      chrome.runtime.sendMessage({ action: "licenseStatusUpdated" });
      return false;
    }

    // Store the license key in Chrome's local storage after successful verification
    if (data.valid) {
      chrome.storage.local.set({ 'licenseKey': licenseKey }, function() {
        console.log('License key is stored in Chrome storage.');
      });
    }

    // Store the license validity in Chrome's local storage
    chrome.storage.local.set({ 'licenseValid': data.valid }, function() {
      console.log('License validity result is stored in Chrome storage.');
      chrome.runtime.sendMessage({ action: "licenseStatusUpdated" });
    });

    return data.valid;
  } catch (error) {
    console.error('Error checking license:', error);
    chrome.runtime.sendMessage({ action: "licenseStatusUpdated" });

    return false;
  }
}

function generateUUID() {
  console.log('Starting UUID generation.');
  // Generate a UUID (RFC 4122 version 4)
  const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
  console.log('Generated UUID:', uuid);
  return uuid;
}

function setUniqueId() {
  console.log('Setting a new unique ID.');
  const uniqueId = generateUUID();
  chrome.storage.local.set({ uniqueId }, function() {
    if (chrome.runtime.lastError) {
      console.error('Error setting unique ID in storage:', chrome.runtime.lastError);
    } else {
      console.log('A new UUID has been generated and stored:', uniqueId);
    }
  });
}

function initializeUUID() {
  console.log('Initializing UUID.');
  chrome.storage.local.get('uniqueId', function(items) {
    if (chrome.runtime.lastError) {
      console.error('Error retrieving unique ID from storage:', chrome.runtime.lastError);
    } else if (items.uniqueId) {
      console.log('UUID already exists:', items.uniqueId);
    } else {
      console.log('No UUID found, creating a new one.');
      setUniqueId();
    }
  });
}

// Main function to initialize the script
async function initializeScript() {

  // Call this function when the extension is installed or started
  initializeUUID();
  chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    console.log(`Received message from sender: ${sender.id} with action: ${request.action}`);
    if (request.action === "verifyLicense") {
      console.log(`Verifying license with key: ${request.licenseKey}`);
      // Retrieve the UUID from Chrome storage and then call checkLicense
      chrome.storage.local.get('uniqueId', async function(items) {
        if (chrome.runtime.lastError) {
          console.error('Error retrieving unique ID from storage:', chrome.runtime.lastError);
          sendResponse({ valid: false });
        } else {
          const uuid = items.uniqueId;
          const isVerified = await checkLicense(request.licenseKey, uuid);
          console.log(`License key verification result: ${isVerified}`);
          sendResponse({ valid: isVerified });
          console.log('Response sent back to sender with verification result.');
        }
      });
      return true; // This indicates that you wish to send a response asynchronously
    }

    // If the message is a request to merge PDFs and no merge is in progress
    if (request.action === "mergePdfs" && !mergeInProgress) {
      mergeInProgress = true;
      console.log('Received a request to merge PDF data');

      // Retrieve the license key and UUID from Chrome storage
      chrome.storage.local.get(['licenseKey', 'uniqueId'], async function(items) {
        if (chrome.runtime.lastError) {
          console.error('Error retrieving data from storage:', chrome.runtime.lastError);
          sendResponse({ valid: false });
          mergeInProgress = false;
        } else {
          const licenseKey = items.licenseKey;
          const uuid = items.uniqueId;

          // Verify the license key directly with the server
          const isVerified = await checkLicense(licenseKey, uuid);
          if (!isVerified) {
            console.error('License key verification failed.');
            sendResponse({ valid: false });
            mergeInProgress = false;
          } else {
            // Proceed with merging the PDFs
            // Removing the Base64 prefix from the PDF data
            const pdfData = request.pdfData.map(base64 => base64.split(',')[1]); 
            console.log('Removed the Base64 prefix from the PDF data');
            // Merging the PDFs
            const mergedPdfBytes = await mergePdfs(pdfData);
            console.log('Merged the PDF data');

            // Checking if the sender tab is available
            if (sender.tab && sender.tab.id) {
              console.log('Sender tab is available');
              console.log('Sending the merged PDF data back to the content script');
              // Sending the merged PDF data back to the content script
              chrome.tabs.sendMessage(sender.tab.id, {action: "mergedPdfData", pdfData: mergedPdfBytes});
              // Sending a message indicating the merge is complete
              chrome.tabs.sendMessage(sender.tab.id, {action: "mergeComplete"});
            } else {
              console.error('Cannot send merged PDF data, no sender tab information');
            }

            // After sending the merged PDF data back to the content script
            mergeInProgress = false;
          }
        }
      });
      return true; // This indicates that you wish to send a response asynchronously
    }
  });

  // Function to merge PDFs
  async function mergePdfs(pdfData) {
    console.log('Starting to merge PDF data');
    // Creating a new PDF document for merging
    const { PDFDocument } = PDFLib;
    const mergedPdf = await PDFDocument.create();
    console.log('Created a new PDF document for merging');

    // Looping through each PDF data
    for (const base64 of pdfData) {
      console.log('Loading PDF data for merging');
      // Converting the base64 data to bytes
      const pdfBytes = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
      // Loading the PDF document from the bytes
      const pdfDoc = await PDFDocument.load(pdfBytes);
      // Copying the pages from the loaded PDF to the merged PDF
      const pages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
      console.log(`Copied ${pages.length} pages from the loaded PDF`);
      // Adding the copied pages to the merged PDF
      pages.forEach(page => mergedPdf.addPage(page));
      console.log('Added pages to the merged PDF');
    }

    console.log('Saving the merged PDF');
    // Saving the merged PDF as a base64 data URI
    const mergedPdfBytes = await mergedPdf.saveAsBase64({ dataUri: true });

    return mergedPdfBytes;
  }
}

// Start the script initialization
initializeScript();
console.log("Popup script loaded - Beginning of script execution");

let licenseInput, verifyButton, otherButtonsContainer, licenseVerified = false;

function showProgressBarAndHideOthers() {
  console.debug("showProgressBarAndHideOthers: Function called");
  // Check if elements exist before trying to modify them
  if (licenseInput) {
    console.debug("showProgressBarAndHideOthers: Hiding licenseInput");
    licenseInput.style.display = 'none';
  }
  if (verifyButton) {
    console.debug("showProgressBarAndHideOthers: Hiding verifyButton");
    verifyButton.style.display = 'none';
  }
  if (otherButtonsContainer) {
    console.debug("showProgressBarAndHideOthers: Hiding otherButtonsContainer");
    otherButtonsContainer.style.display = 'none';
  }

  const progressContainer = document.getElementById('progress-container');
  if (progressContainer) {
    console.debug("showProgressBarAndHideOthers: Showing progressContainer");
    progressContainer.style.display = 'block';

    const progressBar = document.getElementById('progress-bar');
    if (progressBar) {
      console.debug("showProgressBarAndHideOthers: Resetting and showing progressBar");
      progressBar.style.width = '0%'; // Reset progress or set to current progress if known
      progressBar.style.display = 'block'; // Make sure it's visible
    }
  }

  const mergeButton = document.getElementById('merge');
  console.debug("showProgressBarAndHideOthers: Ensuring mergeButton is visible and disabled");
  mergeButton.style.display = 'block'; // Ensure it's visible
  mergeButton.disabled = true; // Keep it disabled
  mergeButton.textContent = 'Creating...'; // Indicate an ongoing operation
  // Example: Adjust the overall layout container if necessary
  const layoutContainer = document.getElementById('layout-container'); // Assuming you have this
  console.debug("showProgressBarAndHideOthers: Adjusting layoutContainer display and flexDirection");
  layoutContainer.style.display = 'flex'; // Or 'block', depending on your layout
  layoutContainer.style.flexDirection = 'column'; // Example for a flex layout
}

function updateUIBasedOnLicense(isValid) {
  console.debug(`updateUIBasedOnLicense: Function called with isValid=${isValid}`);
  if (isValid === false) {
    console.warn("updateUIBasedOnLicense: Invalid license key detected");
    alert('Invalid license key. Please try again.');
  } else if (isValid) {
    console.debug("updateUIBasedOnLicense: License verified successfully");
    licenseVerified = true;
    licenseInput.style.display = 'none';
    verifyButton.style.display = 'none';
    otherButtonsContainer.style.display = 'block';
    console.log("License input and verify button are now hidden. Other buttons container is now visible");
  }
}

function getLicenseStatus() {
  console.debug("getLicenseStatus: Function called");
  chrome.storage.local.get(['licenseValid'], function(result) {
    const isValid = result.licenseValid;
    console.debug(`getLicenseStatus: License validity retrieved as ${isValid}`);
    updateUIBasedOnLicense(isValid);
  });
}

function verifyLicense(licenseKey) {
  console.debug(`verifyLicense: Function called with licenseKey=${licenseKey}`);
  chrome.runtime.sendMessage({action: "verifyLicense", licenseKey: licenseKey}, function(response) {
    const isValid = response.isValid; // Assuming the response contains a boolean indicating validity
    console.debug(`verifyLicense: License validity response received as ${isValid}`);
    chrome.storage.local.set({licenseValid: isValid});
    updateUIBasedOnLicense(isValid);
  });
}

document.addEventListener('DOMContentLoaded', function() {
  console.debug("DOMContentLoaded: Event triggered");
  
  licenseInput = document.getElementById('license-key');
  verifyButton = document.getElementById('verify-button');
  otherButtonsContainer = document.getElementById('merge-container');
  const mergeButton = document.getElementById('merge');

  // Reset UI elements to default state
  console.debug("DOMContentLoaded: Resetting UI elements to default state");
  otherButtonsContainer.style.display = 'none';
  mergeButton.disabled = true;
  mergeButton.textContent = 'Create PDF'; // Reset to default text

  // Initialize UI based on license verification state
  console.debug("DOMContentLoaded: Initializing UI based on license verification state");
  getLicenseStatus();

  verifyButton.addEventListener('click', () => {
    console.debug("verifyButton: Click event triggered");
    verifyLicense(licenseInput.value);
  });

  // Check the current tab's URL before enabling the merge button
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const url = tabs[0].url;
    console.debug(`Current tab's URL: ${url}`);
    // Check if the current URL starts with the base URL
    if (url.startsWith('https://www.ecms.penndot.pa.gov/')) {
      console.debug("URL check passed: Enabling merge button");
      // Enable the merge button if the URL is correct
      mergeButton.disabled = false;
    } else {
      console.warn("URL check failed: Disabling merge button");
      // Inform the user that the button is disabled due to incorrect URL
      mergeButton.textContent = 'Unavailable for this URL';
    }
  });

  mergeButton.addEventListener('click', function() {
    console.debug("mergeButton: Click event triggered");
    if (this.disabled) {
      console.warn("mergeButton: Attempted click while disabled");
      alert('This function is not available for the current URL.');
      return;
    }
    this.textContent = 'Creating...';
    this.disabled = true;

    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      const url = tabs[0].url;
      console.debug(`mergeButton: Attempting content script injection for URL: ${url}`);
      if (url.startsWith('http://') || url.startsWith('https://')) {
        chrome.scripting.executeScript({
          target: {tabId: tabs[0].id},
          files: ["content.js"]
        }).then(() => {
          console.debug("mergeButton: Content script injected successfully");
          chrome.tabs.sendMessage(tabs[0].id, {action: "mergePdfs"});
        }).catch(err => {
          console.error("mergeButton: Error injecting content script", err);
          // Optionally, handle the error for the user here
        });
      } else {
        console.log('Cannot inject content script into this URL:', url);
      }
    });
  });
});

let lastKnownProgress = 0;

chrome.runtime.onMessage.addListener(function(message, sender) {
  console.debug(`Runtime message received: action=${message.action}`);
  if (message.action === 'mergedPdfAvailable') {
    console.debug("Processing 'mergedPdfAvailable' action");
    // Extract the naming data
    
    document.getElementById('progress-container').style.display = 'none';
    lastKnownProgress = 0;
    const fileName = message.namingData;

    // Hide other UI elements
    console.debug("Hiding UI elements post PDF merge");
    licenseInput.style.display = 'none';
    verifyButton.style.display = 'none';
    otherButtonsContainer.style.display = 'none';

    // Set up the download link
    const downloadLinkContainer = document.getElementById('download-link-container');
    const downloadLink = document.getElementById('download-link');
    downloadLink.href = message.pdfData; // The base64 PDF data
    downloadLink.download = fileName; // Use the naming data for the file name
    downloadLinkContainer.style.display = 'block'; // Show the download link container only when the merged PDF is available
  }
  if (message.action === 'pdfCount') {
    console.debug(`Processing 'pdfCount' action with count=${message.count}`);
    const mergeButton = document.getElementById('merge');
    mergeButton.textContent = `Creating ${message.count} PDFs...`;
  } else if (message.action === 'pdfDownloadProgress') {
    console.debug("Processing 'pdfDownloadProgress' action");
    const progressBar = document.getElementById('progress-bar');
    const progressContainer = document.getElementById('progress-container');
    progressContainer.style.display = 'block'; // Show the progress bar container

    // Calculate the percentage of completion
    const percentage = (message.downloaded / message.total) * 100;
    console.debug(`Updating progress bar: ${percentage}% complete`);

    // Update the progress bar only if the new percentage is greater than or equal to the last known progress
    if (percentage >= lastKnownProgress) {
      progressBar.value = percentage; // Update the progress bar
      lastKnownProgress = percentage; // Update the last known progress
    }

    // Optionally, hide the progress bar when download is complete
    if (message.downloaded === message.total) {
      console.debug("Download complete: Hiding progress bar");
      progressContainer.style.display = 'none';
      lastKnownProgress = 0;
    }

  } else if (message.action === 'licenseStatusUpdated') {
    console.debug("Processing 'licenseStatusUpdated' action");
    getLicenseStatus();
  }
});